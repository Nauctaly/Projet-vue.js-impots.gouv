<script setup>
import { normaliserTexte } from '~/utils/texte.js';
const props = defineProps({
  site: {
    type: Object,
    required: true
  }
});
const route = useRoute();
// q contient la recherche dans l’adresse : /recherche?q=impot.
function lireRechercheDansAdresse() {
  if (typeof route.query.q === 'string') {
    return route.query.q;
  }
  return '';
}

const rechercheSaisie = ref(lireRechercheDansAdresse());
watch(() => route.query.q, () => {
  rechercheSaisie.value = lireRechercheDansAdresse();
});

// 1. Rassembler les fiches et les pages dans lesquelles chercher.
const pagesRecherchables = computed(() => {
  const pages = [];

  for (const groupe of props.site.procedures.groups) {
    for (const fiche of groupe.items) {
      let texteDesSections = '';
      for (const section of fiche.sections) {
        texteDesSections += ' ' + section.text;
      }

      pages.push({
        title: fiche.title,
        description: fiche.description,
        to: props.site.links.services + '#' + fiche.slug,
        text: texteDesSections
      });
    }
  }

  for (const page of props.site.specialPages) {
    pages.push(page);
  }

  return pages;
});

// 2. Vérifier que chaque mot saisi existe dans le contenu de la page.
function pageContientLesMots(page, mots) {
  const contenu = page.title + ' ' + (page.description || '') + ' ' + (page.text || '');
  // La normalisation permet d’ignorer les accents et les majuscules.
  const contenuNormalise = normaliserTexte(contenu);

  for (const mot of mots) {
    if (!contenuNormalise.includes(mot)) {
      return false;
    }
  }
  return true;
}

// 3. computed recalcule les résultats quand le texte saisi change.
const resultats = computed(() => {
  const texteRecherche = normaliserTexte(rechercheSaisie.value);
  if (texteRecherche === '') {
    return [];
  }

  const mots = texteRecherche.split(' ');
  const pagesTrouvees = [];
  for (const page of pagesRecherchables.value) {
    if (pageContientLesMots(page, mots)) {
      pagesTrouvees.push(page);
    }
  }
  return pagesTrouvees;
});

function lancerRecherche() {
  navigateTo({
    path: props.site.links.search,
    query: {
      q: rechercheSaisie.value.trim()
    }
  });
}
useHead({
  title: props.site.search.title + ' | ' + props.site.brand.name
});
</script>

<template>
  <div>
    <PageHeading :site="site" :title="site.search.title" :description="site.search.description" />
    <section class="conteneur-page section-espacee contenu-lecture">
      <form class="formulaire-recherche" @submit.prevent="lancerRecherche">
        <label class="texte-lecteur-ecran" for="page-search">{{ site.labels.search }}</label>
        <input
          id="page-search"
          v-model="rechercheSaisie"
          type="search"
          :placeholder="site.labels.searchPlaceholder"
        />
        <CustomButton :text="site.labels.search" icon="search" type="submit" />
      </form>
      <h2>{{ site.search.heading }}</h2>
      <p v-if="rechercheSaisie.trim()" role="status">{{ resultats.length }} {{ site.labels.results }}</p>
      <p v-else class="message-aucun-resultat">{{ site.search.prompt }}</p>
      <div class="liste-resultats">
        <NuxtLink v-for="item in resultats" :key="item.to" :to="item.to">
          <h3>
            {{ item.title }}
            <SiteIcon name="arrow" />
          </h3>
          <p v-if="item.description">{{ item.description }}</p>
        </NuxtLink>
      </div>
      <p v-if="rechercheSaisie.trim() && !resultats.length" class="message-aucun-resultat">{{ site.labels.empty }}</p>
    </section>
  </div>
</template>
