<script setup>
const props = defineProps({ site: { type: Object, required: true } });
useHead({ title: props.site.about.title + ' | ' + props.site.brand.name });
</script>

<template>
  <div>
    <PageHeading :site="site" :title="site.about.title" :description="site.about.description" />
    <div class="conteneur-page section-espacee contenu-lecture contenu-article">
      <section v-for="section in site.about.sections" :id="section.slug" :key="section.slug">
        <h2>{{ section.title }}</h2>
        <p>{{ section.text }}</p>
      </section>
      <NuxtLink class="bouton bouton-contour" :to="site.links.home">
        {{ site.labels.back }}
        <SiteIcon name="arrow" />
      </NuxtLink>
    </div>
  </div>
</template>

