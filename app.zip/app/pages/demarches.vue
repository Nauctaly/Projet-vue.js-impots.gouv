<script setup>
import { useUserStore } from '~/stores/user.store';
import { formulairesDemarches } from '~/data/formulaires-demarches.js';

const userStore = useUserStore();
const props = defineProps({ site: { type: Object, required: true } });
const route = useRoute();
const ancreSelectionnee = ref('');

// Un lien depuis l'accueil ou la recherche ouvre directement la bonne fiche.
onMounted(() => {
  ancreSelectionnee.value = route.hash;
});
watch(() => route.hash, nouvelleAncre => {
  ancreSelectionnee.value = nouvelleAncre;
});
useHead({ title: props.site.procedures.title + ' | ' + props.site.brand.name });
</script>


<template>
  <div>
    <PageHeading :site="site" :title="site.procedures.title" :description="site.procedures.description" />
    <div class="conteneur-page section-espacee disposition-demarches">
      <nav :id="site.procedures.summaryId" class="sommaire-demarches" :aria-label="site.procedures.menuLabel">
        <h2>{{ site.procedures.menuLabel }}</h2>
        <div v-for="group in site.procedures.groups" :key="group.id">
          <NuxtLink class="sommaire-categorie" :to="site.links.services + '#' + group.id">{{ group.title }}</NuxtLink>
          <NuxtLink
            v-for="item in group.items"
            :key="item.slug"
            :to="site.links.services + '#' + item.slug"
            :class="{ 'lien-selectionne': ancreSelectionnee === '#' + item.slug }"
          >
            {{ item.title }}
          </NuxtLink>
        </div>
      </nav>
      <div>
        <section v-for="group in site.procedures.groups" :id="group.id" :key="group.id" class="groupe-demarches">
          <h2>{{ group.title }}</h2>
          <p>{{ group.description }}</p>
          <details
            v-for="item in group.items"
            :id="item.slug"
            :key="item.slug"
            class="bloc-depliable fiche-demarche"
            :open="ancreSelectionnee === '#' + item.slug"
          >
            <summary>
              <SiteIcon :name="item.icon" />
              <span>{{ item.title }}</span>
              <SiteIcon name="down" />
            </summary>
            <div class="fiche-contenu">
              <p>{{ item.description }}</p>
              <section v-for="section in item.sections" :key="section.title">
                <h3>{{ section.title }}</h3>
                <p>{{ section.text }}</p>
              </section>
              <a class="lien-avec-icone" :href="item.source" target="_blank" rel="noopener noreferrer">
                {{ site.labels.official }}
                <SiteIcon name="external" />
              </a>
              <FormulaireDemarche
                v-if="userStore.connectedUser && formulairesDemarches[item.slug]"
                :key="JSON.stringify(userStore.connectedUser) + item.slug"
                :fiche="item"
                :formulaire="formulairesDemarches[item.slug]"
                :textes="site.suiviDemarches"
                :lien-profil="site.links.profile"
              />
              <div v-else-if="formulairesDemarches[item.slug]" class="zone-demarche">
                <p>{{ site.suiviDemarches.connexionRequise }}</p>
                <NuxtLink class="bouton bouton-principal" :to="{ path: site.links.profile, query: { demarche: item.slug } }">
                  {{ site.suiviDemarches.connecter }}
                </NuxtLink>
              </div>
            </div>
          </details>
          <NuxtLink class="lien-avec-icone" :to="site.links.services + '#' + site.procedures.summaryId">
            {{ site.procedures.backToTopics }}
            <SiteIcon name="arrow" />
          </NuxtLink>
        </section>
        <p class="note-information">{{ site.procedures.note }}</p>
      </div>
    </div>
  </div>
</template>
