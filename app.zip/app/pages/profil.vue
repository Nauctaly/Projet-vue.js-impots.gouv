<script setup>
import { useUserStore } from '~/stores/user.store';
import { formulairesDemarches } from '~/data/formulaires-demarches.js';

const props = defineProps({ site: { type: Object, required: true } });
const userStore = useUserStore();
const route = useRoute();


function connecterUtilisateur(valeurs) {
  // Les valeurs reçues ont déjà été validées par le formulaire.
  userStore.connexion(valeurs);
  // Revenir à la fiche choisie avant la connexion, uniquement si elle existe.
  const demarche = route.query.demarche;
  if (userStore.connectedUser && typeof demarche === 'string' && Object.hasOwn(formulairesDemarches, demarche)) {
    navigateTo(props.site.links.services + '#' + demarche);
  }
}

useHead({ title: props.site.profile.title + ' | ' + props.site.brand.name });
</script>

<template>
  <div>
    <PageHeading :site="site" :title="site.profile.title" :description="site.profile.description" />
    <section class="conteneur-page section-espacee contenu-lecture">
      <p class="note-information">{{ site.profile.note }}</p>

      <div v-if="userStore.connectedUser" class="carte-profil">
        <p role="status">{{ site.profile.statut }}</p>
        <h2>{{ site.profile.informations }}</h2>
        <dl class="informations-profil">
          <dt>{{ site.profile.prenom }}</dt>
          <dd>{{ userStore.connectedUser.prenom }}</dd>
          <dt>{{ site.profile.nom }}</dt>
          <dd>{{ userStore.connectedUser.nom }}</dd>
        </dl>
        <CustomButton
          :text="site.profile.deconnexion"
          :show-icon="false"
          @click-a-nous="userStore.deconnexion()"
        />
        <HistoriqueDemarches :site="site" />
      </div>

      <FormulaireConnexion v-else :site="site" @connexion="connecterUtilisateur" />
    </section>
  </div>
</template>
