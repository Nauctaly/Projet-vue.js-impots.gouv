<script setup>
const props = defineProps({ site: { type: Object, required: true } });
useHead({ title: props.site.contact.title + ' | ' + props.site.brand.name });
</script>


<template>
  <div>
    <PageHeading :site="site" :title="site.contact.title" :description="site.contact.description" />
    <div class="conteneur-page section-espacee contenu-lecture">
      <section :id="site.contact.faqId">
        <h2>{{ site.faq.title }}</h2>
        <details v-for="item in site.faq.items" :key="item.question" class="bloc-depliable">
          <summary>
            {{ item.question }}
            <SiteIcon name="down" />
          </summary>
          <p>{{ item.answer }}</p>
        </details>
      </section>
      <section :id="site.contact.contactId" class="encadre-contact">
        <SiteIcon name="chat" />
        <h2>{{ site.contact.heading }}</h2>
        <p>{{ site.contact.text }}</p>
        <a class="bouton bouton-principal" :href="site.contact.url" target="_blank" rel="noopener noreferrer">
          {{ site.contact.action }}
          <SiteIcon name="external" />
        </a>
        <p class="espacement-haut">{{ site.contact.note }}</p>
      </section>
    </div>
  </div>
</template>

