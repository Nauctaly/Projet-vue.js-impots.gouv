<script setup>
import {useAppStore} from '~/stores/app.store'
const appStore = useAppStore()
defineProps({
  site: {
    type: Object,
    required: true
  },
  listeVisible: {
    type: Boolean,
    default: false
  }
});
// La page demande au parent de changer la visibilité de la liste.
const emit = defineEmits(['basculer-liste']);
const darkMode = computed(() => appStore.darkMode)
</script>



<template>
  <div>
    <section class="banniere-accueil">
      <div class="conteneur-page banniere-contenu">
        <div class="banniere-texte">
          <p class="surtitre">{{ site.home.eyebrow }}</p>
          <h1>
            {{ site.home.title }}
            <span>{{ site.home.titleAccent }}</span>
          </h1>
          <p class="banniere-description">{{ site.home.description }}</p>
          <div class="banniere-boutons">
            <NuxtLink class="bouton bouton-principal" :to="site.links.services">
              {{ site.home.primary }}
              <SiteIcon name="arrow" />
            </NuxtLink>
            <NuxtLink class="lien-avec-icone" :to="site.links.contact">
              {{ site.home.secondary }}
              <SiteIcon name="chevron" />
            </NuxtLink>
          </div>
        </div>
        <img class="banniere-illustration" src="~/assets/hero.svg" :alt="site.home.illustrationAlt" />
      </div>
      <div class="banniere-bordure" aria-hidden="true"></div>
    </section>    
    <section class="conteneur-page section-espacee section-publics">
      <div class="entete-section">
        <h2>{{ site.home.profilesTitle }}</h2>
      </div>
      <div class="grille-publics">
        <article v-for="profile in site.home.profiles" :key="profile.to" class="carte-public" :class="profile.color">
          <SiteIcon :name="profile.icon" />
          <div>
            <h3>{{ profile.title }}</h3>
            <p>{{ profile.description }}</p>
            <NuxtLink class="lien-avec-icone" :to="profile.to">
              {{ profile.label }}
              <SiteIcon name="arrow" />
            </NuxtLink>
          </div>
        </article>
      </div>
    </section>
    <section class="conteneur-page section-espacee section-raccourcis">
      <div class="entete-section">
        <div>
          <h2>{{ site.home.quickTitle }}</h2>
          <p>{{ site.home.quickDescription }}</p>
        </div>
        <span class="nombre-demarches" aria-hidden="true">
          {{ site.services.length.toString().padStart(2, '0') }}
        </span>
      </div>
      <div class="grille-demarches">
        <NuxtLink
          v-for="service in site.services"
          :key="service.to"
          :to="service.to"
          class="carte-demarche"
        >
          <SiteIcon :name="service.icon" />
          <h3>{{ service.title }}</h3>
          <SiteIcon name="arrow" />
        </NuxtLink>
      </div>
      <div class="zone-bouton-demarches">
        <CustomButton
          :text="listeVisible ? site.home.hide : site.home.show"
          :show-icon="site.home.showButtonIcon"
          icon="down"
          variant="bouton-discret"
          :aria-expanded="listeVisible"
          :aria-controls="site.home.listId"
          @click-a-nous="emit('basculer-liste')"
        />
      </div>
      <ul v-if="listeVisible" :id="site.home.listId" class="liste-demarches-supplementaires">
        <li v-for="service in site.moreServices" :key="service.to">
          <NuxtLink :to="service.to">
            <SiteIcon :name="service.icon" />
            {{ service.title }}
            <SiteIcon name="arrow" />
          </NuxtLink>
        </li>
      </ul>
    </section>
    <section class="conteneur-page bandeau-aide">
      <div class="illustration-aide" aria-hidden="true">
        <SiteIcon name="chat" />
      </div>
      <div>
        <p class="surtitre">{{ site.home.helpEyebrow }}</p>
        <h2>{{ site.home.helpTitle }}</h2>
        <p>{{ site.home.helpDescription }}</p>
      </div>
      <NuxtLink class="bouton bouton-clair" :to="site.links.contact">
        {{ site.home.helpAction }}
        <SiteIcon name="arrow" />
      </NuxtLink>
    </section>
  </div>
</template>
