// Ignore les accents et les majuscules pendant une recherche.
export function normaliserTexte(texte) {
  return texte.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
}
