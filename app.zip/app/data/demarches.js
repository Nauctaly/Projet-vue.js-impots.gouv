export const procedures = {
  "title": "Toutes vos démarches",
  "description": "Choisissez votre sujet, puis ouvrez sa fiche. Toutes les explications restent sur cette page.",
  "menuLabel": "Accès aux démarches",
  "groups": [
    {
      "id": "particulier",
      "title": "Pour les particuliers",
      "description": "Déclaration, paiement et logement : les démarches du quotidien.",
      "items": [
        {
          "slug": "declarer",
          "title": "Déclarer mes revenus",
          "icon": "document",
          "description": "Une démarche à préparer, étape par étape.",
          "sections": [
            {
              "title": "Rassembler mes documents",
              "text": "Préparez vos justificatifs de revenus et les documents correspondant à votre situation. Conservez-les pour pouvoir vérifier les informations de votre déclaration."
            },
            {
              "title": "Relire avant de valider",
              "text": "Sur le service officiel, vérifiez vos informations personnelles et les montants préremplis. Consultez les instructions qui correspondent à votre situation avant de transmettre la déclaration."
            }
          ],
          "source": "https://www.impots.gouv.fr/particulier"
        },
        {
          "slug": "payer",
          "title": "Payer mes impôts",
          "icon": "card",
          "description": "Retrouver les informations utiles au paiement.",
          "sections": [
            {
              "title": "Consulter mon avis",
              "text": "Votre avis indique le montant, la date limite et les possibilités de règlement. Retrouvez ces informations dans votre véritable espace personnel."
            },
            {
              "title": "Accéder au service de paiement",
              "text": "Ce site ne réalise aucun paiement. Le bouton vers le site officiel permet de consulter les services de la direction générale des Finances publiques."
            }
          ],
          "source": "https://www.impots.gouv.fr/particulier"
        },
        {
          "slug": "prelevement",
          "title": "Gérer mon prélèvement à la source",
          "icon": "chart",
          "description": "Faire le point quand ma situation évolue.",
          "sections": [
            {
              "title": "Un changement de situation",
              "text": "Un changement familial ou professionnel peut modifier votre situation fiscale. Le service officiel vous guide pour signaler les changements qui vous concernent."
            },
            {
              "title": "Retrouver mes informations",
              "text": "Votre espace personnel officiel permet de consulter les informations concernant votre prélèvement. Aucune donnée fiscale n’est demandée sur ce site."
            }
          ],
          "source": "https://www.impots.gouv.fr/particulier"
        },
        {
          "slug": "immobilier",
          "title": "Gérer mes biens immobiliers",
          "icon": "home",
          "description": "Un point de départ pour les démarches des propriétaires.",
          "sections": [
            {
              "title": "Les informations sur mes biens",
              "text": "Le service officiel consacré aux biens immobiliers rassemble les informations et démarches relatives à vos propriétés."
            },
            {
              "title": "Déclarer une évolution",
              "text": "Consultez les indications du service officiel pour connaître les changements à signaler et les informations à préparer."
            }
          ],
          "source": "https://www.impots.gouv.fr/particulier/je-declare-loccupant-de-mon-bien-immobilier"
        },
        {
          "slug": "calendrier",
          "title": "Consulter le calendrier",
          "icon": "calendar",
          "description": "Des repères pour organiser votre année. Consultez le calendrier officiel pour les dates exactes.",
          "sections": [
            {
              "title": "Avant la déclaration",
              "text": "Je rassemble les informations nécessaires à ma situation."
            },
            {
              "title": "Pendant la campagne",
              "text": "Je consulte les dates applicables sur le site officiel."
            },
            {
              "title": "À réception de l’avis",
              "text": "Je vérifie les montants et échéances indiqués sur mon avis."
            },
            {
              "title": "Toute l’année",
              "text": "Je consulte les démarches liées à une évolution de ma situation."
            }
          ],
          "source": "https://www.impots.gouv.fr/particulier/calendrier-fiscal"
        }
      ]
    },
    {
      "id": "professionnel",
      "title": "Pour les professionnels",
      "description": "Les ressources essentielles pour votre entreprise.",
      "items": [
        {
          "slug": "facturation-electronique",
          "title": "La facturation électronique",
          "icon": "briefcase",
          "description": "Des ressources pour préparer les démarches de votre entreprise.",
          "sections": [
            {
              "title": "Comprendre le dispositif",
              "text": "Le dossier officiel présente le fonctionnement de la facturation électronique, les entreprises concernées et les étapes de sa mise en place."
            },
            {
              "title": "Préparer mon organisation",
              "text": "Identifiez vos outils de facturation et les personnes qui les utilisent. Le guide officiel vous aidera à vérifier les modalités et le calendrier applicables à votre entreprise."
            }
          ],
          "source": "https://www.impots.gouv.fr/professionnel/je-passe-la-facturation-electronique"
        },
        {
          "slug": "aides-entreprises",
          "title": "Accompagner mon entreprise",
          "icon": "briefcase",
          "description": "Trouver les ressources adaptées à mon activité.",
          "sections": [
            {
              "title": "Identifier mon besoin",
              "text": "Création, développement ou difficultés : les ressources à consulter dépendent de la situation de votre entreprise."
            },
            {
              "title": "Échanger avec le bon interlocuteur",
              "text": "La rubrique professionnelle du site officiel permet de retrouver les services et contacts utiles pour votre activité."
            }
          ],
          "source": "https://www.impots.gouv.fr/aides-destination-des-entreprises-independants-et-entrepreneurs"
        }
      ]
    }
  ],
  "backToTopics": "Revenir au sommaire",
  "summaryId": "sommaire",
  "note": "Ces fiches sont simplifiées. Pour effectuer une démarche réelle, utilisez le lien vers le site officiel."
};
