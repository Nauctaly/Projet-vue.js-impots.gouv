import { procedures } from './demarches.js';

// Textes et liens communs aux pages.
export const site = {
  procedures,
  "theme": {
    "modeClair": "Passer au mode clair",
    "modeSombre": "Passer au mode sombre"
  },
  "suiviDemarches": {
    "titre": "Mes démarches enregistrées",
    "vide": "Vous n’avez encore enregistré aucune démarche.",
    "commencer": "Choisir une démarche",
    "formulaire": "Réaliser cette démarche",
    "connecter": "Se connecter pour continuer",
    "connexionRequise": "Connectez-vous pour remplir ce formulaire et retrouver la démarche sur votre profil.",
    "note": "Espace personnel local : aucun paiement ni aucune transmission à l’administration. Utilisez des informations d’exemple, sans données sensibles.",
    "enregistrer": "Enregistrer dans mon profil",
    "succes": "La démarche a été enregistrée dans votre profil.",
    "profil": "Voir mes démarches",
    "autre": "Préparer une autre démarche",
    "erreur": "L’enregistrement local a échoué. Vérifiez que le stockage du navigateur est autorisé, puis réessayez.",
    "statut": "Enregistrée dans votre espace",
    "date": "Enregistrée le",
    "reference": "Référence",
    "details": "Consulter les informations saisies",
    "stockage": "Votre historique est conservé dans ce navigateur. Retrouvez-le avec le même prénom et nom. Les profils homonymes partagent le même historique ; cet espace ne dispose pas d’une authentification sécurisée.",
    "supprimer": "Supprimer cette démarche",
    "confirmerSuppression": "Supprimer définitivement cette démarche de votre historique local ?",
    "confirmer": "Confirmer la suppression",
    "annuler": "Annuler",
    "supprimee": "La démarche a été supprimée.",
    "erreurSuppression": "La suppression a échoué. La démarche n’a pas été supprimée du stockage."
  },
  "validation": {
    "annee": "Le champ {champ} doit contenir une année entre 1900 et 2100.",
    "montant": "Le champ {champ} doit contenir un montant positif, avec au maximum deux décimales.",
    "dateValide": "Le champ {champ} doit contenir une date valide.",
    "required": "Le champ {champ} est obligatoire.",
    "min": "Le champ {champ} doit contenir au moins {limite} caractères.",
    "max": "Le champ {champ} doit contenir au maximum {limite} caractères.",
    "email": "Le champ {champ} doit contenir une adresse e-mail valide.",
    "invalide": "Le champ {champ} est invalide.",
    "one_of": "Choisissez une option proposée pour {champ}.",
    "integer": "Le champ {champ} doit contenir un nombre entier.",
    "min_value": "Le champ {champ} doit être supérieur ou égal à {limite}.",
    "max_value": "Le champ {champ} doit être inférieur ou égal à {limite}.",
    "taux": "Le champ {champ} doit contenir un pourcentage entre 0 et 100, avec au maximum deux décimales."
  },
  "profile": {
    "champs": [
      {
        "name": "prenom",
        "label": "Prénom",
        "rules": "required|min:2|max:80",
        "iconLeft": "user",
        "iconRight": ""
      },
      {
        "name": "nom",
        "label": "Nom",
        "rules": "required|min:2|max:80",
        "iconLeft": "user",
        "iconRight": ""
      }
    ],
    "title": "Mon profil",
    "description": "Retrouvez vos informations et vos démarches enregistrées.",
    "connection": "Connexion",
    "deconnexion": "Se déconnecter",
    "formulaire": "Renseigner mon profil",
    "nom": "Nom",
    "prenom": "Prénom",
    "action": "Se connecter",
    "informations": "Mes informations",
    "statut": "Vous êtes connecté à votre espace.",
    "note": "Espace local indépendant des services officiels. Après rechargement, reconnectez-vous avec les mêmes noms pour retrouver votre historique."
  },
  "language": "fr",
  "title": "Accueil | Vos démarches",
  "description": "Préparez vos démarches et retrouvez vos informations dans votre espace personnel.",
  "links": {
    "profile": "/profil",
    "home": "/",
    "main": "#main-content",
    "search": "/recherche",
    "contact": "/contact",
    "services": "/demarches",
    "official": "https://www.impots.gouv.fr/accueil"
  },
  "brand": {
    "name": "impots.gouv.fr",
    "description": "Les Finances publiques à vos côtés",
    "republic": [
      "RÉPUBLIQUE",
      "FRANÇAISE"
    ],
    "motto": "Liberté · Égalité · Fraternité",
    "home": "/",
    "homeLabel": "Retour à l’accueil"
  },
  "labels": {
    "skip": "Aller au contenu",
    "home": "Accueil",
    "search": "Rechercher",
    "searchPlaceholder": "Rechercher une démarche…",
    "menu": "Menu",
    "close": "Fermer",
    "navigation": "Navigation principale",
    "breadcrumb": "Fil d’Ariane",
    "contact": "Aide et contact",
    "official": "Consulter le site officiel",
    "back": "Retour à l’accueil",
    "empty": "Aucun résultat. Essayez un autre mot-clé.",
    "results": "résultat(s)",
    "externalSuffix": "site officiel, nouvel onglet",
    "choisirOption": "Choisir une option"
  },
  "navigation": [
    {
      "label": "Accueil",
      "to": "/",
      "icon": "home"
    },
    {
      "label": "Particulier",
      "to": "/demarches#particulier",
      "section": "particulier"
    },
    {
      "label": "Professionnel",
      "to": "/demarches#professionnel",
      "section": "professionnel"
    },
    {
      "label": "Contact et RDV",
      "to": "/contact",
      "icon": "chat"
    }
  ],
  "services": [
    {
      "title": "Déclarer mes revenus",
      "to": "/demarches#declarer",
      "icon": "document",
      "description": "Retrouver les étapes de ma déclaration."
    },
    {
      "title": "Payer mes impôts",
      "to": "/demarches#payer",
      "icon": "card",
      "description": "Choisir mon moyen de paiement."
    },
    {
      "title": "Gérer mon prélèvement",
      "to": "/demarches#prelevement",
      "icon": "chart",
      "description": "Comprendre le prélèvement à la source."
    },
    {
      "title": "Consulter le calendrier",
      "to": "/demarches#calendrier",
      "icon": "calendar",
      "description": "Préparer mes prochaines démarches."
    }
  ],
  "moreServices": [
    {
      "title": "Gérer mes biens immobiliers",
      "to": "/demarches#immobilier",
      "icon": "home"
    },
    {
      "title": "La facturation électronique",
      "to": "/demarches#facturation-electronique",
      "icon": "briefcase"
    },
    {
      "title": "Accompagner mon entreprise",
      "to": "/demarches#aides-entreprises",
      "icon": "briefcase"
    }
  ],
  "home": {
    "eyebrow": "BIENVENUE SUR IMPOTS.GOUV.FR",
    "title": "Vos démarches fiscales,",
    "titleAccent": "tout simplement.",
    "description": "Particuliers et professionnels : retrouvez vos démarches fiscales, les services en ligne et les réponses à vos questions.",
    "primary": "Voir les démarches",
    "secondary": "Besoin d’aide ?",
    "illustrationAlt": "Illustration de documents, d’un logement et d’une calculatrice",
    "quickTitle": "Vos démarches les plus courantes",
    "quickDescription": "Choisissez une démarche pour accéder directement à ses explications.",
    "show": "Voir les autres démarches",
    "hide": "Masquer les autres démarches",
    "listId": "additional-services",
    "showButtonIcon": true,
    "helpEyebrow": "NOUS SOMMES À VOS CÔTÉS",
    "helpTitle": "Une question ? Un seul point de contact.",
    "helpDescription": "Les réponses aux questions fréquentes et les moyens de nous contacter sont réunis sur une seule page.",
    "helpAction": "Consulter l’aide",
    "profilesTitle": "Les services adaptés à votre situation",
    "profiles": [
      {
        "title": "Vous êtes un particulier",
        "description": "Déclarer vos revenus, payer vos impôts, gérer votre prélèvement et vos biens immobiliers.",
        "to": "/demarches#particulier",
        "label": "Mes démarches de particulier",
        "icon": "user",
        "color": "fond-bleu-clair"
      },
      {
        "title": "Vous êtes un professionnel",
        "description": "Facturation électronique et accompagnement : retrouvez les ressources utiles à votre entreprise.",
        "to": "/demarches#professionnel",
        "label": "Mes démarches professionnelles",
        "icon": "briefcase",
        "color": "fond-peche"
      }
    ]
  },
  "contact": {
    "title": "Aide et contact",
    "description": "Consultez les réponses ci-dessous ou retrouvez les contacts officiels.",
    "faqId": "questions",
    "contactId": "contacter",
    "heading": "Besoin d’un interlocuteur ?",
    "text": "Le portail officiel vous permet de trouver votre service et de prendre rendez-vous.",
    "action": "Trouver mon contact officiel",
    "url": "https://www.impots.gouv.fr/contacts",
    "note": "Aucun rendez-vous n’est réservé depuis ce site."
  },
  "faq": {
    "title": "Questions fréquentes",
    "items": [
      {
        "question": "Puis-je déclarer ou payer sur ce site ?",
        "answer": "Non. Ce site est un exercice Vue.js. Pour effectuer une démarche réelle, utilisez exclusivement le site officiel impots.gouv.fr."
      },
      {
        "question": "Où retrouver mes documents fiscaux ?",
        "answer": "Rendez-vous dans votre espace personnel sur le portail officiel. Ce site ne stocke aucun document fiscal."
      },
      {
        "question": "Comment contacter mon service ?",
        "answer": "Le lien « Trouver mon contact officiel », juste sous ces questions, vous mène vers le service de contact du portail officiel."
      }
    ]
  },
  "search": {
    "title": "Rechercher sur le site",
    "description": "Une démarche, un service, une information : trouvez votre point de départ.",
    "prompt": "Saisissez un mot-clé pour explorer les rubriques.",
    "heading": "Résultats de recherche"
  },
  "specialPages": [
    {
      "title": "Toutes vos démarches",
      "to": "/demarches"
    },
    {
      "title": "Aide et contact",
      "to": "/contact"
    },
    {
      "title": "À propos du site",
      "to": "/a-propos"
    }
  ],
  "about": {
    "title": "À propos du site",
    "description": "Fonctionnement du site, confidentialité et accessibilité.",
    "sections": [
      {
        "slug": "mentions-legales",
        "title": "Mentions légales",
        "description": "Fonctionnement et limites du service.",
        "text": "Ce site est indépendant du portail impots.gouv.fr et ne représente pas l’administration. Il permet de préparer et conserver des démarches dans votre navigateur. Aucun paiement ni envoi officiel n’est effectué. Les liens vers les services publics permettent d’accéder aux démarches officielles."
      },
      {
        "slug": "confidentialite",
        "title": "Confidentialité",
        "description": "Le stockage de vos informations dans votre navigateur.",
        "text": "Les informations saisies sont conservées dans ce navigateur et associées au prénom et au nom. Il n’y a pas de compte sécurisé : deux profils homonymes partagent le même historique. Ne saisissez pas de données sensibles. Vous pouvez supprimer chaque démarche depuis le profil. Effacer les données du navigateur efface aussi l’historique. Les services externes appliquent leurs propres règles de confidentialité."
      },
      {
        "slug": "accessibilite",
        "title": "Accessibilité",
        "description": "Un site conçu pour être simple à parcourir.",
        "text": "Les liens et boutons sont accessibles au clavier. Un lien permet d’aller directement au contenu. Les champs de recherche possèdent un libellé et les icônes décoratives sont ignorées par les lecteurs d’écran. Ce site n’a pas fait l’objet d’un audit de conformité RGAA."
      }
    ]
  },
  "footer": {
    "description": "Espace indépendant des services publics. Aucune démarche n’est transmise à l’administration.",
    "copyright": "Vos démarches · Espace personnel",
    "links": [
      {
        "label": "Aide et contact",
        "to": "/contact"
      },
      {
        "label": "À propos du site",
        "to": "/a-propos"
      }
    ]
  },
  "error": {
    "title": "Cette page est introuvable",
    "description": "Le lien ne correspond à aucune page de ce site."
  },
  "accounts": [
    {
      "label": "Mon espace particulier",
      "href": "https://cfspart.impots.gouv.fr/",
      "icon": "user"
    },
    {
      "label": "Mon espace professionnel",
      "href": "https://cfspro.impots.gouv.fr/mire/accueil.do",
      "icon": "briefcase"
    }
  ]
};
