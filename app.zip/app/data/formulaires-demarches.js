export const formulairesDemarches = {
  "declarer": {
    "titre": "Préparer une déclaration de revenus",
    "champs": [
      {
        "name": "annee",
        "label": "Année des revenus",
        "rules": "required|annee"
      },
      {
        "name": "revenus",
        "label": "Revenus annuels en euros",
        "rules": "required|montant"
      },
      {
        "name": "situation",
        "label": "Situation familiale",
        "rules": "required|one_of:Célibataire,Marié(e),Pacsé(e),Divorcé(e),Veuf / veuve",
        "type": "select",
        "options": [
          "Célibataire",
          "Marié(e)",
          "Pacsé(e)",
          "Divorcé(e)",
          "Veuf / veuve"
        ]
      },
      {
        "name": "personnes",
        "label": "Personnes à charge",
        "rules": "required|integer|min_value:0|max_value:20",
        "type": "text",
        "options": []
      },
      {
        "name": "observations",
        "label": "Précisions (facultatif)",
        "rules": "max:500",
        "type": "textarea",
        "options": []
      }
    ]
  },
  "payer": {
    "titre": "Préparer un paiement",
    "champs": [
      {
        "name": "reference",
        "label": "Référence de l’avis",
        "rules": "required|min:3|max:80"
      },
      {
        "name": "montant",
        "label": "Montant en euros",
        "rules": "required|montant"
      },
      {
        "name": "impot",
        "label": "Type d’impôt",
        "rules": "required|one_of:Impôt sur le revenu,Taxe foncière,Autre",
        "type": "select",
        "options": [
          "Impôt sur le revenu",
          "Taxe foncière",
          "Autre"
        ]
      },
      {
        "name": "echeance",
        "label": "Date d’échéance",
        "rules": "required|dateValide",
        "type": "date",
        "options": []
      },
      {
        "name": "mode",
        "label": "Mode de règlement envisagé",
        "rules": "required|one_of:Paiement en ligne,Prélèvement,Autre",
        "type": "select",
        "options": [
          "Paiement en ligne",
          "Prélèvement",
          "Autre"
        ]
      }
    ]
  },
  "prelevement": {
    "titre": "Préparer un changement de prélèvement",
    "champs": [
      {
        "name": "motif",
        "label": "Changement de situation",
        "rules": "required|min:3|max:120"
      },
      {
        "name": "revenus",
        "label": "Nouveaux revenus annuels en euros",
        "rules": "required|montant"
      },
      {
        "name": "dateEffet",
        "label": "Date du changement",
        "rules": "required|dateValide",
        "type": "date",
        "options": []
      },
      {
        "name": "taux",
        "label": "Taux envisagé en pourcentage",
        "rules": "required|taux",
        "type": "text",
        "options": []
      },
      {
        "name": "precisions",
        "label": "Précisions (facultatif)",
        "rules": "max:500",
        "type": "textarea",
        "options": []
      }
    ]
  },
  "immobilier": {
    "titre": "Enregistrer une situation immobilière",
    "champs": [
      {
        "name": "bien",
        "label": "Nom du bien",
        "rules": "required|min:3|max:80"
      },
      {
        "name": "occupation",
        "label": "Situation d’occupation",
        "rules": "required|min:3|max:120"
      },
      {
        "name": "typeBien",
        "label": "Type de bien",
        "rules": "required|one_of:Appartement,Maison,Local,Autre",
        "type": "select",
        "options": [
          "Appartement",
          "Maison",
          "Local",
          "Autre"
        ]
      },
      {
        "name": "surface",
        "label": "Surface en m²",
        "rules": "required|montant",
        "type": "text",
        "options": []
      },
      {
        "name": "dateOccupation",
        "label": "Début de la situation d’occupation",
        "rules": "required|dateValide",
        "type": "date",
        "options": []
      }
    ]
  },
  "calendrier": {
    "titre": "Ajouter une échéance personnelle",
    "champs": [
      {
        "name": "objet",
        "label": "Intitulé de l’échéance",
        "rules": "required|min:3|max:80"
      },
      {
        "name": "date",
        "label": "Date de l’échéance",
        "type": "date",
        "rules": "required|dateValide"
      },
      {
        "name": "categorie",
        "label": "Catégorie",
        "rules": "required|one_of:Déclaration,Paiement,Rendez-vous,Autre",
        "type": "select",
        "options": [
          "Déclaration",
          "Paiement",
          "Rendez-vous",
          "Autre"
        ]
      },
      {
        "name": "priorite",
        "label": "Priorité",
        "rules": "required|one_of:Normale,Importante,Urgente",
        "type": "select",
        "options": [
          "Normale",
          "Importante",
          "Urgente"
        ]
      },
      {
        "name": "notes",
        "label": "Notes (facultatif)",
        "rules": "max:500",
        "type": "textarea",
        "options": []
      }
    ]
  },
  "facturation-electronique": {
    "titre": "Préparer la facturation électronique",
    "champs": [
      {
        "name": "entreprise",
        "label": "Nom de l’entreprise",
        "rules": "required|min:2|max:80"
      },
      {
        "name": "outil",
        "label": "Outil de facturation envisagé",
        "rules": "required|min:2|max:120"
      },
      {
        "name": "taille",
        "label": "Taille de l’entreprise",
        "rules": "required|one_of:Indépendant,Moins de 10 salariés,10 à 249 salariés,250 salariés ou plus",
        "type": "select",
        "options": [
          "Indépendant",
          "Moins de 10 salariés",
          "10 à 249 salariés",
          "250 salariés ou plus"
        ]
      },
      {
        "name": "datePrevue",
        "label": "Date de mise en place envisagée",
        "rules": "required|dateValide",
        "type": "date",
        "options": []
      },
      {
        "name": "details",
        "label": "Organisation prévue (facultatif)",
        "rules": "max:500",
        "type": "textarea",
        "options": []
      }
    ]
  },
  "aides-entreprises": {
    "titre": "Préparer une demande d’accompagnement",
    "champs": [
      {
        "name": "entreprise",
        "label": "Nom de l’entreprise",
        "rules": "required|min:2|max:80"
      },
      {
        "name": "besoin",
        "label": "Besoin d’accompagnement",
        "rules": "required|min:10|max:500",
        "type": "textarea"
      },
      {
        "name": "sujet",
        "label": "Sujet de la demande",
        "rules": "required|one_of:Création,Développement,Difficultés,Autre",
        "type": "select",
        "options": [
          "Création",
          "Développement",
          "Difficultés",
          "Autre"
        ]
      },
      {
        "name": "dateSouhaitee",
        "label": "Date de contact souhaitée",
        "rules": "required|dateValide",
        "type": "date",
        "options": []
      },
      {
        "name": "urgence",
        "label": "Niveau d’urgence",
        "rules": "required|one_of:Sans urgence,Dans le mois,Dès que possible",
        "type": "select",
        "options": [
          "Sans urgence",
          "Dans le mois",
          "Dès que possible"
        ]
      }
    ]
  }
};
