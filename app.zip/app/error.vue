<script setup>
import { site } from '~/data/site.js';
defineProps({
  error: {
    type: Object,
    required: true
  }
});
</script>
<template>
  <main class="conteneur-page section-espacee">
    <p class="surtitre">{{ error.statusCode }}</p>
    <h1>{{ site.error.title }}</h1>
    <p>{{ site.error.description }}</p>
    <CustomButton
      :text="site.labels.back"
      @click-a-nous="clearError({ redirect: site.links.home })"
    />
  </main>
</template>
