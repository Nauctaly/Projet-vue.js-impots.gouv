import { defineRule, configure } from 'vee-validate';
import { required, email, min, max, integer, min_value, max_value, one_of } from '@vee-validate/rules';
import { site } from '~/data/site.js';

export default defineNuxtPlugin(() => {
  // Les espaces seuls ne doivent pas permettre de se connecter.
  defineRule('required', valeur => required(typeof valeur === 'string' ? valeur.trim() : valeur));
  defineRule('email', email);
  defineRule('min', (valeur, parametres) => min(typeof valeur === 'string' ? valeur.trim() : valeur, parametres));
  defineRule('max', max);
  defineRule('integer', integer);
  defineRule('min_value', min_value);
  defineRule('max_value', max_value);
  defineRule('taux', valeur => {
    const texte = String(valeur).trim();
    const nombre = Number(texte.replace(',', '.'));
    return /^\d+([.,]\d{1,2})?$/.test(texte) && nombre >= 0 && nombre <= 100;
  });
  defineRule('one_of', one_of);
  defineRule('annee', valeur => /^\d{4}$/.test(String(valeur)) && Number(valeur) >= 1900 && Number(valeur) <= 2100);
  defineRule('montant', valeur => /^\d{1,10}([.,]\d{1,2})?$/.test(String(valeur).trim()) && Number(String(valeur).replace(',', '.')) > 0);
  defineRule('dateValide', valeur => {
    const date = String(valeur);
    const timestamp = Date.parse(date);
    return /^\d{4}-\d{2}-\d{2}$/.test(date) && Number.isFinite(timestamp)
      && new Date(timestamp).toISOString().slice(0, 10) === date;
  });

  configure({
    generateMessage: contexte => {
      const regle = contexte.rule;
      const message = site.validation[regle?.name] || site.validation.invalide;
      return message
        .replace('{champ}', contexte.field)
        .replace('{limite}', String(regle?.params?.[0] || ''));
    }
  });
});
