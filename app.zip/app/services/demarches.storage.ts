import type { Demarche, InformationDemarche } from '../types/demarche';

// Conserver cette clé permet de retrouver les démarches déjà enregistrées.
const cleStockage = 'demarches-locales-v1';

function estInformation(valeur: unknown): valeur is InformationDemarche {
  if (!valeur || typeof valeur !== 'object') return false;
  return 'label' in valeur && typeof valeur.label === 'string'
    && 'valeur' in valeur && typeof valeur.valeur === 'string';
}

function estDemarche(valeur: unknown): valeur is Demarche {
  if (!valeur || typeof valeur !== 'object') return false;
  return 'id' in valeur && typeof valeur.id === 'string'
    && 'proprietaire' in valeur && typeof valeur.proprietaire === 'string'
    && 'slug' in valeur && typeof valeur.slug === 'string'
    && 'titre' in valeur && typeof valeur.titre === 'string'
    && 'date' in valeur && typeof valeur.date === 'string' && Number.isFinite(Date.parse(valeur.date))
    && 'informations' in valeur && Array.isArray(valeur.informations)
    && valeur.informations.every(estInformation);
}

export function lireDemarches(): Demarche[] {
  const donnees: unknown = JSON.parse(localStorage.getItem(cleStockage) || '[]');
  if (!Array.isArray(donnees) || !donnees.every(estDemarche)) {
    throw new Error('Historique local invalide');
  }
  return donnees;
}

export function sauvegarderDemarches(demarches: Demarche[]) {
  localStorage.setItem(cleStockage, JSON.stringify(demarches));
}
