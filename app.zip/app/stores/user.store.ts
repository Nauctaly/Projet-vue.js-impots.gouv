import { defineStore } from 'pinia';

// Le type décrit les informations contenues dans un utilisateur.
export interface Utilisateur {
  nom: string;
  prenom: string;
}

export const useUserStore = defineStore('user', {
  state: () => ({
    connectedUser: null as Utilisateur | null
  }),
  actions: {
    // Connexion de démonstration : on remplit simplement la variable partagée.
    connexion(utilisateur: Utilisateur) {
      const nom = utilisateur.nom.trim();
      const prenom = utilisateur.prenom.trim();
      if (!nom || !prenom) return;
      this.connectedUser = { nom, prenom };
    },
    deconnexion() {
      this.connectedUser = null;
    }
  }
});
