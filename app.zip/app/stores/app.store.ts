// config que l'utilisateur peut choisir (couleurs, langues, dark/light)
import { defineStore } from 'pinia'
import { ref } from 'vue'

export const useAppStore = defineStore('app', () => {
    const darkMode = ref(false)
    // Le bouton appelle cette fonction pour passer de clair à sombre, et inversement.
    function toggleDarkMode() {
        darkMode.value = !darkMode.value
    }

    // Le return rend la variable et la fonction accessibles aux composants.
    return { darkMode, toggleDarkMode }
})
