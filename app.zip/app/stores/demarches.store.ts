import { defineStore } from 'pinia';
import { useUserStore } from './user.store';
import { lireDemarches, sauvegarderDemarches } from '../services/demarches.storage';
import type { Demarche } from '../types/demarche';

// L'identité locale reste identique pour préserver les anciens historiques.
function identifierUtilisateur() {
  const utilisateur = useUserStore().connectedUser;
  if (!utilisateur) return null;
  return JSON.stringify([
    utilisateur.prenom.trim().toLocaleLowerCase('fr'),
    utilisateur.nom.trim().toLocaleLowerCase('fr')
  ]);
}

export const useDemarchesStore = defineStore('demarches', {
  state: () => ({ demarches: [] as Demarche[] }),
  getters: {
    mesDemarches(state) {
      const proprietaire = identifierUtilisateur();
      return state.demarches.filter(demarche => demarche.proprietaire === proprietaire);
    }
  },
  actions: {
    charger() {
      try {
        this.demarches = lireDemarches();
        return true;
      } catch {
        return false;
      }
    },
    enregistrer(slug: string, titre: string, informations: Demarche['informations']) {
      const proprietaire = identifierUtilisateur();
      if (!proprietaire) return false;
      try {
        const demarche: Demarche = {
          id: crypto.randomUUID(), proprietaire, slug, titre,
          date: new Date().toISOString(), informations
        };
        const liste = [demarche, ...lireDemarches()];
        sauvegarderDemarches(liste);
        this.demarches = liste;
        return true;
      } catch {
        return false;
      }
    },
    supprimer(id: string) {
      const proprietaire = identifierUtilisateur();
      if (!proprietaire) return false;
      try {
        const liste = lireDemarches();
        // On ne peut supprimer que les démarches du profil connecté.
        const demarche = liste.find(element => element.id === id && element.proprietaire === proprietaire);
        if (!demarche) return false;
        const restantes = liste.filter(element => element !== demarche);
        sauvegarderDemarches(restantes);
        // L'écran change uniquement après la sauvegarde réussie.
        this.demarches = restantes;
        return true;
      } catch {
        return false;
      }
    }
  }
});
