export interface InformationDemarche {
  label: string;
  valeur: string;
}

export interface Demarche {
  id: string;
  proprietaire: string;
  slug: string;
  titre: string;
  date: string;
  informations: InformationDemarche[];
}
