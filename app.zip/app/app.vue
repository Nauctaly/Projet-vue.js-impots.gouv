<script setup>
import { site } from './data/site.js';
import { useAppStore } from './stores/app.store';

const appStore = useAppStore();
// Le cookie conserve uniquement le thème, même après avoir rechargé la page.
const themeSombre = useCookie('theme-sombre', { default: () => false, maxAge: 31536000 });
appStore.darkMode = themeSombre.value === true;
watch(() => appStore.darkMode, valeur => {
  themeSombre.value = valeur;
});

// Le CSS applique les couleurs du thème à partir de cet attribut HTML.
useHead(() => ({
  htmlAttrs: { 'data-theme': appStore.darkMode ? 'sombre' : 'clair' }
}));

// Le parent conserve l'état ; les enfants reçoivent des props et envoient un événement.
const listeVisible = ref(false);
// .value permet de lire ou modifier une ref dans le script.
// Le point d’exclamation inverse la valeur : true devient false, et inversement.
function basculerListe() {
  listeVisible.value = !listeVisible.value;
}
useHead({
  htmlAttrs: {
    lang: site.language
  },
  title: site.title,
  meta: [{
    name: 'description',
    content: site.description
  }]
});
</script>

<template>
  <NuxtRouteAnnouncer />
  <NuxtLayout :site="site">
    <NuxtPage :site="site" :liste-visible="listeVisible" @basculer-liste="basculerListe" />
  </NuxtLayout>
</template>
