<script setup>
defineProps({
  site: {
    type: Object,
    required: true
  }
});
</script>

<template>
  <div>
    <a class="lien-vers-contenu" :href="site.links.main">{{ site.labels.skip }}</a>
    <MainNavbar :site="site" />
    <main id="main-content" tabindex="-1">
      <slot />
    </main>
    <MainFooter :site="site" />
  </div>
</template>
