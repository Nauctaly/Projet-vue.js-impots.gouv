<script setup>
defineProps({
  site: {
    type: Object,
    required: true
  },
  title: {
    type: String,
    required: true
  },
  description: {
    type: String,
    default: ''
  },
  eyebrow: {
    type: String,
    default: ''
  }
});
</script>

<template>
  <div class="entete-page">
    <div class="conteneur-page">
      <nav class="fil-ariane" :aria-label="site.labels.breadcrumb">
        <NuxtLink :to="site.links.home">{{ site.labels.home }}</NuxtLink>
        <SiteIcon name="chevron" />
        <span>{{ title }}</span>
      </nav>
      <p v-if="eyebrow" class="surtitre">{{ eyebrow }}</p>
      <h1>{{ title }}</h1>
      <p v-if="description" class="description-page">{{ description }}</p>
    </div>
  </div>
</template>
