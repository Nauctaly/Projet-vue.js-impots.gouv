<script setup>
import { useField } from 'vee-validate';
import { site } from '~/data/site.js';

const props = defineProps({
  name: { type: String, required: true },
  id: { type: String, default: '' },
  label: { type: String, required: true },
  rules: { type: String, default: '' },
  type: { type: String, default: 'text' },
  options: { type: Array, default: () => [] },
  iconLeft: { type: String, default: '' },
  iconRight: { type: String, default: '' },
  autocomplete: { type: String, default: 'off' }
});

// Chaque input s’enregistre dans le useForm de son parent grâce à son nom.
const { value, errorMessage, handleBlur } = useField(
  () => props.name,
  toRef(props, 'rules'),
  { label: toRef(props, 'label') }
);
const identifiant = computed(() => props.id || 'champ-' + props.name);
</script>

<template>
  <div class="champ-formulaire">
    <label :for="identifiant">{{ label }}</label>
    <div class="champ-avec-icones" :class="{ 'champ-invalide': errorMessage }">
      <SiteIcon v-if="iconLeft" :name="iconLeft" />
      <select
        v-if="type === 'select'"
        :id="identifiant"
        v-model="value"
        :name="name"
        :aria-invalid="Boolean(errorMessage)"
        :aria-describedby="errorMessage ? identifiant + '-erreur' : undefined"
        @blur="handleBlur"
      >
        <option value="">{{ site.labels.choisirOption }}</option>
        <option v-for="option in options" :key="option" :value="option">{{ option }}</option>
      </select>
      <textarea
        v-else-if="type === 'textarea'"
        :id="identifiant"
        v-model="value"
        :name="name"
        rows="4"
        :aria-invalid="Boolean(errorMessage)"
        :aria-describedby="errorMessage ? identifiant + '-erreur' : undefined"
        @blur="handleBlur"
      />
      <input
        v-else
        :id="identifiant"
        v-model="value"
        :name="name"
        :type="type"
        :autocomplete="autocomplete"
        :aria-invalid="Boolean(errorMessage)"
        :aria-describedby="errorMessage ? identifiant + '-erreur' : undefined"
        @blur="handleBlur"
      />
      <SiteIcon v-if="iconRight" :name="iconRight" />
    </div>
    <p v-if="errorMessage" :id="identifiant + '-erreur'" class="erreur-champ" role="alert">
      {{ errorMessage }}
    </p>
  </div>
</template>
