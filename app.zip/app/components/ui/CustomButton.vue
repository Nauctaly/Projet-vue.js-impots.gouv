<script setup>
// Les props sont les réglages choisis par le parent du bouton.
// text : texte, showIcon : afficher l’icône, icon : nom de l’icône.
// variant : classe CSS de couleur, type : bouton simple ou envoi du formulaire.
defineProps({
  text: {
    type: String,
    required: true
  },
  showIcon: {
    type: Boolean,
    default: true
  },
  icon: {
    type: String,
    default: 'arrow'
  },
  variant: {
    type: String,
    default: 'bouton-principal'
  },
  type: {
    type: String,
    default: 'button'
  }
});
// L’enfant signale le clic ; le parent décide de l’action à effectuer.
const emit = defineEmits(['clickANous']);
</script>

<template>
  <button :type="type" class="bouton" :class="variant" @click="emit('clickANous', $event)">
    <span>{{ text }}</span>
    <SiteIcon v-if="showIcon" :name="icon" />
  </button>
</template>
