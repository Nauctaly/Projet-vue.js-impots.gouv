<script setup>
import { icons } from '~/data/icones.js';
defineProps({
  name: {
    type: String,
    default: 'arrow'
  }
});
</script>

<template>
  <svg
    class="icone"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="1.6"
    stroke-linecap="round"
    stroke-linejoin="round"
    aria-hidden="true"
  >
    <path :d="icons[name] || icons.arrow" />
  </svg>
</template>
