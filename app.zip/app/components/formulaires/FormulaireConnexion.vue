<script setup>
import { useForm } from 'vee-validate';

const props = defineProps({ site: { type: Object, required: true } });
const emit = defineEmits(['connexion']);
// Attendre que Vue soit prêt évite une soumission HTML avant l’hydratation.
const formulairePret = ref(false);
onMounted(() => { formulairePret.value = true; });

const { handleSubmit, isSubmitting } = useForm({
  initialValues: { prenom: '', nom: '' }
});

// handleSubmit transmet les valeurs uniquement si tous les champs sont valides.
// La page reçoit ensuite l’événement et remplit le store.
const soumettreFormulaire = handleSubmit(valeurs => {
  emit('connexion', valeurs);
});
</script>

<template>
  <form class="formulaire-profil" novalidate @submit="soumettreFormulaire">
    <h2>{{ site.profile.formulaire }}</h2>
    <CustomInput
      v-for="champ in site.profile.champs"
      :key="champ.name"
      :name="champ.name"
      :label="champ.label"
      :rules="champ.rules"
      :icon-left="champ.iconLeft"
      :icon-right="champ.iconRight"
    />
    <CustomButton
      :text="site.profile.action"
      :show-icon="false"
      type="submit"
      :disabled="!formulairePret || isSubmitting"
    />
  </form>
</template>
