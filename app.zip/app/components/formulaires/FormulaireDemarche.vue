<script setup>
import { useForm } from 'vee-validate';
import { useDemarchesStore } from '~/stores/demarches.store';

const props = defineProps({
  fiche: { type: Object, required: true },
  formulaire: { type: Object, required: true },
  textes: { type: Object, required: true },
  lienProfil: { type: String, required: true }
});
const demarchesStore = useDemarchesStore();
const enregistre = ref(false);
const erreur = ref(false);
const formulairePret = ref(false);
onMounted(() => { formulairePret.value = true; });
const { handleSubmit, isSubmitting, resetForm } = useForm();

const enregistrer = handleSubmit(valeurs => {
  // Une copie des libellés et valeurs permet de relire la démarche sur le profil.
  const informations = [];
  for (const champ of props.formulaire.champs) {
    const valeur = String(valeurs[champ.name] ?? '').trim();
    if (valeur) informations.push({ label: champ.label, valeur });
  }
  const resultat = demarchesStore.enregistrer(props.fiche.slug, props.formulaire.titre, informations);
  erreur.value = !resultat;
  enregistre.value = resultat;
});

function recommencer() {
  resetForm();
  enregistre.value = false;
  erreur.value = false;
}
</script>

<template>
  <div class="zone-demarche">
    <p class="note-information">{{ textes.note }}</p>
    <div v-if="enregistre" class="confirmation-demarche">
      <p role="status">{{ textes.succes }}</p>
      <NuxtLink class="bouton bouton-principal" :to="lienProfil">{{ textes.profil }}</NuxtLink>
      <CustomButton :text="textes.autre" :show-icon="false" variant="bouton-contour" @click-a-nous="recommencer" />
    </div>
    <form v-else class="formulaire-profil" novalidate @submit="enregistrer">
      <h3>{{ formulaire.titre }}</h3>
      <CustomInput
        v-for="champ in formulaire.champs"
        :id="fiche.slug + '-' + champ.name"
        :key="champ.name"
        :name="champ.name"
        :label="champ.label"
        :type="champ.type || 'text'"
        :rules="champ.rules"
        :options="champ.options || []"
        :icon-left="fiche.icon"
      />
      <p v-if="erreur" class="erreur-champ" role="alert">{{ textes.erreur }}</p>
      <CustomButton :text="textes.enregistrer" :show-icon="false" type="submit" :disabled="!formulairePret || isSubmitting" />
    </form>
  </div>
</template>
