<script setup>
import { useDemarchesStore } from '~/stores/demarches.store';

const props = defineProps({ site: { type: Object, required: true } });
const demarchesStore = useDemarchesStore();
const erreurChargement = ref(false);
const suppressionEnAttente = ref(null);
const erreurSuppression = ref(false);
const suppressionReussie = ref(false);

function supprimerDemarche(id) {
  const resultat = demarchesStore.supprimer(id);
  erreurSuppression.value = !resultat;
  suppressionReussie.value = resultat;
  if (resultat) suppressionEnAttente.value = null;
}
onMounted(() => {
  erreurChargement.value = !demarchesStore.charger();
});

function afficherDate(date) {
  return new Intl.DateTimeFormat(props.site.language, {
    dateStyle: 'long', timeStyle: 'short'
  }).format(new Date(date));
}
</script>

<template>
  <section class="historique-demarches">
    <h2>{{ site.suiviDemarches.titre }}</h2>
    <p>{{ site.suiviDemarches.stockage }}</p>
    <p v-if="suppressionReussie" role="status">{{ site.suiviDemarches.supprimee }}</p>
    <p v-if="erreurSuppression" class="erreur-champ" role="alert">{{ site.suiviDemarches.erreurSuppression }}</p>
    <p v-if="erreurChargement" class="erreur-champ" role="alert">{{ site.suiviDemarches.erreur }}</p>
    <p v-else-if="!demarchesStore.mesDemarches.length" class="message-aucun-resultat">{{ site.suiviDemarches.vide }}</p>
    <NuxtLink class="bouton bouton-principal" :to="site.links.services">{{ site.suiviDemarches.commencer }}</NuxtLink>
    <article v-for="demarche in demarchesStore.mesDemarches" :key="demarche.id" class="carte-demarche-enregistree">
      <h3>{{ demarche.titre }}</h3>
      <p class="statut-demarche">{{ site.suiviDemarches.statut }}</p>
      <p>{{ site.suiviDemarches.date }} <time :datetime="demarche.date">{{ afficherDate(demarche.date) }}</time></p>
      <p class="reference-demarche">{{ site.suiviDemarches.reference }} : {{ demarche.id }}</p>
      <details>
        <summary>{{ site.suiviDemarches.details }}</summary>
        <dl class="informations-profil">
          <template v-for="information in demarche.informations" :key="information.label">
            <dt>{{ information.label }}</dt>
            <dd>{{ information.valeur }}</dd>
          </template>
        </dl>
      </details>
      <div v-if="suppressionEnAttente === demarche.id" class="confirmation-suppression">
        <p role="alert">{{ site.suiviDemarches.confirmerSuppression }}</p>
        <CustomButton :text="site.suiviDemarches.confirmer" :show-icon="false" @click-a-nous="supprimerDemarche(demarche.id)" />
        <CustomButton :text="site.suiviDemarches.annuler" :show-icon="false" variant="bouton-contour" @click-a-nous="suppressionEnAttente = null" />
      </div>
      <CustomButton
        v-else
        class="espacement-haut"
        :text="site.suiviDemarches.supprimer"
        :show-icon="false"
        variant="bouton-contour"
        @click-a-nous="suppressionEnAttente = demarche.id; suppressionReussie = false; erreurSuppression = false"
      />
    </article>
  </section>
</template>
