<script setup>
import { useAppStore } from '~/stores/app.store';
import { useUserStore } from '~/stores/user.store';

const appStore = useAppStore();
const userStore = useUserStore();
const props = defineProps({
  site: {
    type: Object,
    required: true
  }
});
const rechercheSaisie = ref('');
const menuOuvert = ref(false);
const route = useRoute();
const ancreActuelle = ref('');
// L’ancre est la partie de l’adresse après #, par exemple #immobilier.
onMounted(() => {
  ancreActuelle.value = route.hash;
});
watch(() => route.fullPath, () => {
  menuOuvert.value = false;
  ancreActuelle.value = route.hash;
});
// Chaque fiche appartient à un public : un seul onglet reste actif.
function ongletEstActif(item) {
  if (!item.section) return route.path === item.to;
  if (route.path !== props.site.links.services) return false;
  const group = props.site.procedures.groups.find(group => group.id === item.section);
  return ancreActuelle.value === '#' + group.id
    || group.items.some(fiche => ancreActuelle.value === '#' + fiche.slug);
}
function lancerRecherche() {
  navigateTo({
    path: props.site.links.search,
    query: {
      q: rechercheSaisie.value.trim()
    }
  });
}
</script>

<template>
  <header class="entete-site">
    <div class="bandeau-demonstration">
      <div class="conteneur-page">{{ site.labels.demo }}</div>
    </div>
    <div class="conteneur-page entete-contenu">
      <SiteBrand :brand="site.brand" />
      <div class="entete-outils">
        <div class="commandes-utilisateur">
          <CustomButton
            :text="appStore.darkMode ? site.theme.modeClair : site.theme.modeSombre"
            :show-icon="false"
            variant="bouton-contour"
            :aria-pressed="appStore.darkMode"
            @click-a-nous="appStore.toggleDarkMode()"
          />
          <NuxtLink :to="site.links.profile" class="lien-avec-icone">
            <SiteIcon name="user" />
            <span v-if="userStore.connectedUser">
              {{ userStore.connectedUser.prenom }} {{ userStore.connectedUser.nom }}
            </span>
            <span v-else>{{ site.profile.connection }}</span>
          </NuxtLink>
          <CustomButton
            v-if="userStore.connectedUser"
            :text="site.profile.deconnexion"
            :show-icon="false"
            variant="bouton-discret"
            @click-a-nous="userStore.deconnexion()"
          />
        </div>
        <div class="liens-espaces-personnels">
          <a
            v-for="account in site.accounts"
            :key="account.href"
            :href="account.href"
            :aria-label="account.label + ' — ' + site.labels.externalSuffix"
            target="_blank"
            rel="noopener noreferrer"
          >
            <SiteIcon :name="account.icon" />
            {{ account.label }}
            <SiteIcon name="external" />
          </a>
        </div>
        <form class="recherche-entete" role="search" @submit.prevent="lancerRecherche">
          <label class="texte-lecteur-ecran" for="header-search">{{ site.labels.search }}</label>
          <input
            id="header-search"
            v-model="rechercheSaisie"
            type="search"
            :placeholder="site.labels.searchPlaceholder"
          />
          <button type="submit" :aria-label="site.labels.search">
            <SiteIcon name="search" />
          </button>
        </form>
      </div>
      <CustomButton
        class="bouton-menu-mobile"
        :text="menuOuvert ? site.labels.close : site.labels.menu"
        icon="menu"
        variant="bouton-contour"
        :aria-expanded="menuOuvert"
        aria-controls="navigation"
        @click-a-nous="menuOuvert = !menuOuvert"
      />
    </div>
    <nav
      id="navigation"
      class="navigation-principale"
      :class="{ 'menu-ouvert': menuOuvert }"
      :aria-label="site.labels.navigation"
    >
      <div class="conteneur-page liste-liens-navigation">
        <NuxtLink
          v-for="item in site.navigation"
          :key="item.to"
          :to="item.to"
          active-class=""
          exact-active-class=""
          :class="{ 'onglet-actif': ongletEstActif(item) }"
          :aria-current="ongletEstActif(item) ? 'page' : undefined"
        >
          <SiteIcon v-if="item.icon" :name="item.icon" />
          <span>{{ item.label }}</span>
        </NuxtLink>
      </div>
    </nav>
  </header>
</template>
