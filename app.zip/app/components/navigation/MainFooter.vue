<script setup>
defineProps({ site: { type: Object, required: true } });
</script>

<template>
  <footer class="pied-de-page">
    <div class="conteneur-page pied-de-page-identite">
      <SiteBrand :brand="site.brand" />
      <p>{{ site.footer.description }}</p>
    </div>
    <div class="conteneur-page pied-de-page-liens">
      <NuxtLink v-for="link in site.footer.links" :key="link.to" :to="link.to">{{ link.label }}</NuxtLink>
      <span>{{ site.footer.copyright }}</span>
    </div>
  </footer>
</template>

