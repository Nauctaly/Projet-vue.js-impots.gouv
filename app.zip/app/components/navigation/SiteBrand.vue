<script setup>
defineProps({
  brand: {
    type: Object,
    required: true
  }
});
</script>

<template>
  <NuxtLink :to="brand.home" class="identite-site" :aria-label="brand.homeLabel">
    <div class="bloc-republique">
      <span class="drapeau-francais" aria-hidden="true"></span>
      <strong v-for="line in brand.republic" :key="line">{{ line }}</strong>
      <span class="devise-republique">{{ brand.motto }}</span>
    </div>
    <div class="nom-site">
      <strong>{{ brand.name }}</strong>
      <span>{{ brand.description }}</span>
    </div>
  </NuxtLink>
</template>
